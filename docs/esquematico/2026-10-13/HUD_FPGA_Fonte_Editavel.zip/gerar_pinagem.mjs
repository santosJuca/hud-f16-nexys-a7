import fs from 'node:fs/promises';
import path from 'node:path';
import { Workbook } from '@oai/artifact-tool';

const out = process.argv[2];
if (!out) throw new Error('Informe a pasta do esquemático.');
const dados = JSON.parse(await fs.readFile(path.join(out, 'pinagem_dados.json'), 'utf8'));
const workbook = Workbook.create();
const sheet = workbook.worksheets.add('Pinagem');
const range = sheet.getRange(`A1:J${dados.length}`);
range.values = dados;
workbook.recalculate();
const values = range.values;
if (values.length !== 49) throw new Error('Esperadas 48 portas e um cabeçalho.');
if (new Set(values.slice(1).map(row => row[2])).size !== 48) throw new Error('Pads duplicados.');
const escape = value => {
  const text = String(value ?? '');
  return /[;"\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
};
const csv = '\ufeff' + values.map(row => row.map(escape).join(';')).join('\n') + '\n';
await fs.writeFile(path.join(out, 'HUD_FPGA_Pinagem.csv'), csv);
console.log('CSV exportado: 48 portas, sem duplicação de pads.');
