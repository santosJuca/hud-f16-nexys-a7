# Fonte editável do esquemático

Os SVGs são editáveis em Inkscape ou outro editor vetorial. O PDF tem três
folhas A3 vetoriais. Os valores externos não informados estão marcados como NI.

`gerar_esquematico.py` lê o XDC do projeto e gera PDF, SVG, PNG e a matriz JSON
de pinagem. Requer Python, CairoSVG e pypdf. A pasta de saída é a pasta do script.
A variável HUD_REPO permite selecionar outra cópia das fontes preservadas.

O CSV foi exportado por `gerar_pinagem.mjs`, com @oai/artifact-tool, a partir da
matriz `pinagem_dados.json`. Pode ser editado diretamente como CSV UTF-8 com BOM
e separador ponto e vírgula. A cópia do XDC está em ../versao_gravada/.

O texto de validação do esquema corresponde aos relatos de 13/10/2026.
Ao mudar a montagem ou os valores, atualize também esse texto e a pinagem.
