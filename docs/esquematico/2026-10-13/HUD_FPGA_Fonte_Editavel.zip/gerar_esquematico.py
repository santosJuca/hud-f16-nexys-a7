from pathlib import Path
import re, csv, html, sys, os
import cairosvg
from pypdf import PdfReader, PdfWriter

DEFAULT_ROOT=Path(__file__).resolve().parent
if not (DEFAULT_ROOT/'constraints/nexys_a7_reticula.xdc').exists():
    DEFAULT_ROOT=Path('/home/santojuca/Downloads/Trabalho-display-aviao-v2')
ROOT=Path(os.environ.get('HUD_REPO',str(DEFAULT_ROOT)))
OUT=Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)
W,H=1680,1188
BLUE='#0067a5'; RED='#b3261e'; INK='#172b3a'; GRAY='#526575'; PALE='#eaf3f8'; GOLD='#c18a00'; GREEN='#25734a'

# Parse all active package assignments from the current XDC, including expanded vector bits.
xdc=(ROOT/'constraints/nexys_a7_reticula.xdc').read_text()
xdc='\n'.join(line.split('#',1)[0] for line in xdc.splitlines())
assign={}
for m in re.finditer(r'set_property\s+-dict\s*\{([^}]*)\}\s*\\?\s*\[get_ports\s*\{([^}]*)\}\]', xdc, re.S):
    props,port=m.groups(); pin=re.search(r'PACKAGE_PIN\s+(\w+)',props); ios=re.search(r'IOSTANDARD\s+(\w+)',props); pullup=re.search(r'PULLUP\s+(\w+)',props)
    if pin:
        assign[port.strip()]=(pin.group(1),ios.group(1) if ios else '',pullup.group(1) if pullup else '')
# manual board/device mappings from Nexys A7-100T pin map / official schematic
conn={
'clk':('Oscilador onboard','CLK100MHZ','100 MHz'),
'i2c_sda':('JD','8','MPU-6050 SDA'), 'i2c_scl':('JD','7','MPU-6050 SCL'),
'baro_sda':('JD','1','BMP085 SDA'), 'baro_scl':('JD','2','BMP085 SCL'),
'mag_sda':('JD','3','HMC5883L SDA'), 'mag_scl':('JD','9','HMC5883L SCL'),
'vauxp3':('JXADC','1','VAUXP3 / X'), 'vauxn3':('JXADC','7','VAUXN3 / X'),
'vauxp10':('JXADC','2','VAUXP10 / Y'), 'vauxn10':('JXADC','8','VAUXN10 / Y'),
'joystick_sw_n':('JC','1','KY-023 SW'), 'buzzer_out':('JC','7','Buzzer control'),
'display_mode':('SW0','—','Display mode'), 'style_mode':('SW1','—','HUD style'),
'operacao_sw[0]':('SW2','—','Mode bit 0'), 'operacao_sw[1]':('SW3','—','Mode bit 1'),
'btn_heading[0]':('BTNU','—','Heading +10°'), 'btn_heading[1]':('BTND','—','Heading -10°'), 'ack_btn':('BTNC','—','Alert acknowledge'),
'sw[9]':('SW9','—','Disable MPU attitude'), 'sw[10]':('SW10','—','Disable barometer'), 'sw[11]':('SW11','—','Disable magnetometer'),
'sw[12]':('SW12','—','Manual pitch bit 0'), 'sw[13]':('SW13','—','Manual pitch bit 1'), 'sw[14]':('SW14','—','Manual roll bit 0'), 'sw[15]':('SW15','—','Manual roll bit 1'),
'GYRO_LED':('LD4','—','MPU status'), 'BARO_LED':('LD5','—','BMP085 status'), 'MAG_LED':('LD6','—','HMC5883L status'),
'JOY_LED[0]':('LD0','—','Joystick X−'), 'JOY_LED[1]':('LD1','—','Joystick X+'), 'JOY_LED[2]':('LD2','—','Joystick Y−'), 'JOY_LED[3]':('LD3','—','Joystick Y+'),
}
for sig,prefix,pintext in [('VGA_R','VGA_R',''),('VGA_G','VGA_G',''),('VGA_B','VGA_B','')]:
    for i in range(4): conn[f'{sig}[{i}]']=('J2',str({'VGA_R':1,'VGA_G':2,'VGA_B':3}[sig]),f'DE-15 {sig}[{i}] via R')
conn['VGA_HS']=('J2','13','DE-15 HS via 100 Ω'); conn['VGA_VS']=('J2','14','DE-15 VS via 100 Ω')

def direction(sig):
    if sig in {'clk','vauxp3','vauxn3','vauxp10','vauxn10','joystick_sw_n','display_mode','style_mode','ack_btn'} or sig.startswith(('sw[','btn_heading[','operacao_sw[')): return 'Entrada'
    if sig.startswith(('i2c_','baro_','mag_')): return 'Bidirecional'
    return 'Saída'
def logical_name(sig):
    return sig

def state_for(sig):
    if sig.startswith('vaux'):
        return 'XDC e DCP conferidos; quatro sentidos, centro e limites relatados; resistores e faixa 0 a 1 V nao medidos'
    if sig.startswith(('i2c_','baro_','mag_')):
        return 'XDC e DCP conferidos; funcionamento relatado pelo operador; tensoes e pull-ups nao medidos'
    if sig=='buzzer_out': return 'JC7/E7 conferido; buzzer e ACK relatados; resistor de base e alimentacao nao informados'
    if sig=='joystick_sw_n': return 'JC1/K1 conferido; LOCK/UNLOCK relatado em CACA'
    if sig.startswith('VGA_'): return 'Pinagem conferida; imagem estavel relatada em bancada apos boot pela Flash'
    return 'Mapeamento XDC/DCP e recurso Nexys conferidos; funcao individual conforme relatorio de bancada'

rows=[]
for sig,(pin,ios,pu) in assign.items():
    c=conn.get(sig,('—','—',''))
    rows.append([logical_name(sig),sig,pin,c[0],c[1],c[2],direction(sig),ios,('PULLUP '+pu if pu else '—'),state_for(sig)])
rows.sort(key=lambda r:(r[3],r[4],r[0]))
import json
headers=['nome_logico_RTL','porta_XDC','PACKAGE_PIN_FPGA','conector_recurso','contato_fisico','destino_funcao','direcao','IOSTANDARD_XDC','pullup_XDC','estado_validacao']
(OUT/'pinagem_dados.json').write_text(json.dumps([headers]+rows,ensure_ascii=False,indent=2),encoding='utf-8')

# Basic XDC integrity checks; flag duplicates, unmapped top pins and vectors.
pins=[v[0] for v in assign.values()]
assert len(pins)==len(set(pins)), 'PACKAGE_PIN duplicado no XDC ativo'
assert len(assign)==48, f'Esperadas 48 atribuições ativas do XDC, analisadas: {len(assign)}'

E=[]
def add(s): E.append(s)
def esc(s): return html.escape(str(s),quote=True)
def rect(x,y,w,h,fill='white',stroke=BLUE,sw=2,rx=0): add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
def line(x1,y1,x2,y2,color=BLUE,sw=3): add(f'<path d="M{x1} {y1} L{x2} {y2}" fill="none" stroke="{color}" stroke-width="{sw}" stroke-linecap="round"/>')
def poly(points,color=BLUE,sw=3): add(f'<polyline points="{points}" fill="none" stroke="{color}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"/>')
def text(x,y,s,size=18,color=INK,bold=False,anchor='start',family='DejaVu Sans'):
    add(f'<text x="{x}" y="{y}" font-family="{family}" font-size="{size}" fill="{color}" font-weight="{700 if bold else 400}" text-anchor="{anchor}">{esc(s)}</text>')
def dot(x,y): add(f'<circle cx="{x}" cy="{y}" r="5" fill="{BLUE}"/>')
def chip(x,y,w,h,title,subtitle=''):
    rect(x,y,w,h,'#fff',INK,2,8); text(x+18,y+32,title,21,INK,True)
    if subtitle: text(x+18,y+58,subtitle,15,GRAY)
def resistor_h(x,y,label,value,width=70):
    # IEC rectangular resistor, with reference and value on the same label line.
    line(x,y,x+12,y); rect(x+12,y-9,width-24,18,'white',BLUE,2,0); line(x+width-12,y,x+width,y)
    text(x+width/2,y-14,f'{label}  {value}',13,RED,True,'middle')
def title(page,title_,sub):
    rect(22,22,W-44,H-44,'white',INK,2,0)
    text(55,74,'HUD FPGA  /  ESQUEMÁTICO ELÉTRICO',18,BLUE,True)
    text(55,120,title_,32,INK,True)
    text(55,151,sub,16,GRAY)
    line(55,169,W-55,169,INK,1)
    text(55,H-59,'Nexys A7-100T  •  xc7a100tcsg324-1  •  Rev. 13/10/2026 | XDC/DCP + Digilent | bancada relatada pelo operador',13,GRAY)
    text(W-55,H-59,f'FOLHA {page} / 3',14,INK,True,'end')
def start():
    E.clear(); add(f'<svg xmlns="http://www.w3.org/2000/svg" width="420mm" height="297mm" viewBox="0 0 {W} {H}">'); add('<rect width="100%" height="100%" fill="white"/>')
def finish(): add('</svg>'); return '\n'.join(E)

# SHEET 1: sensor and external interfaces, with actual headers/pins and FPGA package pads.
start(); title(1,'Sensores, joystick e saída de alerta','Pinagem XDC/DCP conferida. Montagem e funcionamento relatados; valores externos e tensões ainda não medidos.')
# FPGA symbol with actual package-pad mapping
chip(1175,202,450,600,'U1  •  FPGA Artix-7','')
chip(690,202,430,72,'U2  •  OSCILADOR ONBOARD','100 MHz → clk / E3')
poly('1120,238 1148,238 1148,310 1175,310',BLUE,3)
text(1200,270,'PORTA RTL',15,GRAY,True); text(1375,270,'PAD FPGA',15,GRAY,True); text(1490,270,'CONECTOR',13,GRAY,True)
fpga_rows=[('clk','E3','100 MHz'),('i2c_sda','G4','JD8'),('i2c_scl','H2','JD7'),('baro_sda','H4','JD1'),('baro_scl','H1','JD2'),('mag_sda','G1','JD3'),('mag_scl','G2','JD9'),('vauxp3','A13','JXADC1'),('vauxn3','A14','JXADC7'),('vauxp10','A15','JXADC2'),('vauxn10','A16','JXADC8'),('joystick_sw_n','K1','JC1'),('buzzer_out','E7','JC7')]
for j,(p,pad,c) in enumerate(fpga_rows):
    pad=assign[p][0]
    yy=310+j*39; line(1175,yy,1195,yy); text(1200,yy+5,p,16,INK); text(1375,yy+5,pad,16,RED,True); text(1490,yy+5,c,14,GRAY)
    if j in (1,3,5,9): line(1195,yy+15,1605,yy+15,'#c8d5de',1)
# External sensor packages and contacts
chip(55,210,485,190,'J1  •  PMOD JD','Header 2×6; 3 I²C masters use independent contacts')
text(78,298,'JD1/H4 BMP085 SDA',13); text(78,328,'JD2/H1 BMP085 SCL',13)
text(78,358,'JD3/G1 HMC5883L SDA',13); text(273,298,'JD7/H2 MPU SCL',13); text(273,328,'JD8/G4 MPU SDA',13); text(273,358,'JD9/G2 HMC SCL',13)
text(482,278,'JD',12,BLUE,True,'middle')
for col,x in enumerate((464,505)):
    for row_i in range(6):
        number=row_i+1+(6 if col else 0); yy=286+row_i*16
        fill='#dbeef8' if number in (1,2,3,7,8,9) else 'white'
        add(f'<circle cx="{x}" cy="{yy}" r="7" fill="{fill}" stroke="{BLUE if number in (1,2,3,7,8,9) else GRAY}" stroke-width="1.5"/>')
        text(x,yy+3,str(number),8,INK,True,'middle')
text(421,391,'5/11 GND • 6/12 3V3',9,GRAY)
# Wire identifiers from the shared JD connector to FPGA pin rows
for start_y,fpga_i,label in [(298,2,'baro_sda'),(328,3,'baro_scl'),(358,4,'mag_sda'),(387,5,'i2c_sda'),(387,1,'i2c_scl')]: pass
# draw labelled pair networks, no implied shared bus between independent sensor buses
for idx,(sig,pad,contact,yy,rref) in enumerate([
 ('i2c_sda','G4','JD8 / 8',349,'R6'),('i2c_scl','H2','JD7 / 7',388,'R2'),('baro_sda','H4','JD1 / 1',427,'R1'),('baro_scl','H1','JD2 / 2',466,'R5'),('mag_sda','G1','JD3 / 3',505,'R9'),('mag_scl','G2','JD9 / 9',544,'R10')]):
    line(540,yy,770,yy); text(550,yy-8,f'{contact}  •  {sig}',14,BLUE,True); resistor_h(770,yy,rref,'200 Ω',92); line(862,yy,1175,yy); dot(1175,yy)
# external sensor mini-symbols and circuit notes
chip(55,430,485,145,'J2  •  JXADC','KY-023 analog axes; differential inputs, not GPIO')
text(78,510,'X → VAUX3: +A13 / −A14  (JXADC 1 / 7)',16)
text(78,540,'Y → VAUX10: +A15 / −A16 (JXADC 2 / 8)',16)
text(78,566,'Top: horizontal = VAUX10; vertical = 4095 - VAUX3.',12,GRAY)
chip(55,585,485,95,'J3  •  PMOD JC','JC1 contact 1 → KY-023 SW; active-low input')
text(78,670,'K1  •  joystick_sw_n  •  PULLUP TRUE no XDC',14,INK)
chip(55,710,485,100,'JC7  •  SAÍDA PARA BUZZER','E7 / buzzer_out; 2N2222A externo (folha 3)')
# analog + button + buzzer named wires to FPGA package rows
for yy,s in [(583,'VAUXP3 X+'),(622,'VAUXN3 X−'),(661,'VAUXP10 Y+'),(700,'VAUXN10 Y−')]:
    line(540,yy,1175,yy); text(720,yy-7,s,14,BLUE,True); dot(1175,yy)
for yy,s,rref in [(739,'JC1 SW','R17'),(778,'JC7 buzzer','R18')]:
    line(540,yy,770,yy); text(550,yy-8,s,14,BLUE,True); resistor_h(770,yy,rref,'200 Ω',92); line(862,yy,1175,yy); dot(1175,yy)
# Arrays de protecao da placa, somente canais ligados aos sinais usados.
rect(55,835,485,216,'white',BLUE,2,6)
text(75,865,'PROTEÇÕES ONBOARD A GND',17,INK,True)
for gx,gy,ref,nets in [(85,892,'D1',['JD1','JD2','JD3']),(310,892,'D2',['JD7','JD8','JD9']),(85,982,'D5',['JC1']),(310,982,'D6',['JC7'])]:
    text(gx,gy,ref+' / canais usados',12,RED,True)
    for k,net in enumerate(nets):
        xx=gx+30+k*50
        text(xx,gy+17,net,10,BLUE,True,'middle');line(xx,gy+21,xx,gy+28,BLUE,2)
        add(f'<polygon points="{xx-6},{gy+39} {xx+6},{gy+39} {xx},{gy+28}" fill="white" stroke="{BLUE}" stroke-width="1.5"/>')
        line(xx-7,gy+28,xx+7,gy+28,BLUE,2);line(xx,gy+39,xx,gy+48,BLUE,2)
    line(gx+30,gy+48,gx+30+(len(nets)-1)*50,gy+48,BLUE,2)
    cx=gx+30+(len(nets)-1)*25
    line(cx,gy+48,cx,gy+54,BLUE,2);line(cx-12,gy+54,cx+12,gy+54,BLUE,2)
    line(cx-8,gy+60,cx+8,gy+60,BLUE,2)

# warning panel
rect(585,835,1040,216,'#fff9e9',GOLD,2,6)
text(610,874,'PENDÊNCIAS ELÉTRICAS EXTERNAS',20,GOLD,True)
text(610,909,'I²C: funcionamento relatado; confirmar tensões e pull-ups dos breakouts. Barramentos separados.',16)
text(610,939,'XADC: IOSTANDARD LVCMOS33 não define faixa analógica. Conferir os divisores e o limite de 1 V.',16)
text(610,969,'Joystick: quatro sentidos, repouso, limites e LOCK/UNLOCK relatados. Valores dos divisores pendentes.',16)
text(610,999,'Buzzer: JC7/E7 → resistor de base → 2N2222A; áudio e ACK relatados; tensão e resistor pendentes.',16)
text(610,1027,'PMOD JD/JC: resistores em série de 200 Ω; arrays D1/D2 e D5/D6 ligados ao GND (canais usados representados).',15)
sheet1=finish()

# SHEET 2: board controls, LEDs and the official VGA resistor DAC.
start(); title(2,'Controles da placa, LEDs e vídeo VGA','XDC: 48 pads únicos; clock 100 MHz / pixel_clk ÷4; constraints comentadas não são ativas.')
# FPGA box/control terminals
chip(55,205,630,550,'U1  •  FPGA Artix-7','')
text(80,284,'ENTRADAS DE CONTROLE  •  PACKAGE_PIN / RECURSO',15,BLUE,True)
controls=[('display_mode','J15','SW0'),('style_mode','L16','SW1'),('operacao_sw[0]','M13','SW2'),('operacao_sw[1]','R15','SW3'),('sw[9]','U8','SW9 · LVCMOS18'),('sw[10]','R16','SW10'),('sw[11]','T13','SW11'),('sw[12]','H6','SW12'),('sw[13]','U12','SW13'),('sw[14]','U11','SW14'),('sw[15]','V10','SW15'),('btn_heading[0]','M18','BTNU'),('btn_heading[1]','P18','BTND'),('ack_btn','N17','BTNC')]
for i,(sig,pad,board) in enumerate(controls):
    yy=320+i*29
    text(80,yy,sig,15); text(325,yy,pad,15,RED,True); text(420,yy,board,15,GRAY)
    line(685,yy-5,710,yy-5)
text(80,731,'BTNU/BTND/BTNC: série R51/R53/R55; pull-down R63/R61/R62; todos 10 kΩ.',12,GRAY)
text(80,750,'SW0–3/SW9–15: resistores de 10 kΩ; SW9 usa o banco de 1,8 V.',12,GRAY)
# Board controls symbols grouped, labels and link traces
chip(735,205,340,270,'S1–S15  •  SWITCHES','Recursos onboard Nexys A7')
for i,(sig,pad,board) in enumerate(controls[:11]):
    yy=295+i*16
    # mini-switch stylization and package/net labels
    line(755,yy,777,yy); line(777,yy,790,yy-5,INK,2); line(790,yy-5,807,yy,INK,2)
    text(815,yy+4,board.split(' · ')[0],13,INK,True); text(920,yy+4,pad,13,RED)
chip(1098,205,527,250,'BTNU / BTND / BTNC','Contatos integrados na placa; entradas digitais')
for i,(b,p) in enumerate([('BTNU','M18'),('BTND','P18'),('BTNC','N17')]):
    yy=290+i*48; add(f'<circle cx="1140" cy="{yy}" r="17" fill="white" stroke="{BLUE}" stroke-width="3"/>'); text(1175,yy+5,b,16,INK,True); text(1355,yy+5,'FPGA '+p,15,RED,True)
# LED circuits, represent on-board LED as standard diode symbol with series resistor known? schematic LED circuit differs; use board LED resource symbol no series R detail unless exact. Official sheet 2 has LEDs LD0-15 circuits, include driver resistor? Page 1 visual includes R etc. We'll mark resource indicator.
chip(735,485,890,270,'LD0–LD6  •  INDICADORES DA PLACA','LEDs onboard são cargas da placa; resistores existentes ficam no circuito Nexys.')
leds=[('JOY_LED[0]','H17','LD0 / X−'),('JOY_LED[1]','K15','LD1 / X+'),('JOY_LED[2]','J13','LD2 / Y−'),('JOY_LED[3]','N14','LD3 / Y+'),('GYRO_LED','R18','LD4 / MPU'),('BARO_LED','V17','LD5 / BMP'),('MAG_LED','U17','LD6 / HMC')]
for i,(sig,pad,ld) in enumerate(leds):
    col=i%4; row=i//4; x=765+col*208; yy=560+row*82
    text(x,yy,f'{sig}  /  {pad}',12,INK,True); line(x,yy+32,x+6,yy+32); resistor_h(x+6,yy+32,{'LD0':'R33','LD1':'R34','LD2':'R36','LD3':'R39','LD4':'R41','LD5':'R44','LD6':'R47'}[ld.split(' /')[0]],'330 Ω',82); line(x+88,yy+32,x+103,yy+32); add(f'<polygon points="{x+103},{yy+20} {x+103},{yy+44} {x+120},{yy+32}" fill="white" stroke="{BLUE}" stroke-width="2"/>'); line(x+123,yy+20,x+123,yy+44); line(x+112,yy+17,x+122,yy+7,BLUE,2); line(x+122,yy+7,x+122,yy+13,BLUE,2); line(x+122,yy+7,x+116,yy+7,BLUE,2); line(x+123,yy+32,x+127,yy+32); line(x+127,yy+32,x+127,yy+53); line(x+118,yy+53,x+136,yy+53,BLUE,2); line(x+121,yy+58,x+133,yy+58,BLUE,2); text(x+131,yy+37,ld,12,RED,True)
# VGA section bottom across page
rect(55,790,1570,315,'white',INK,2,6); text(80,827,'J2  •  VGA ANALÓGICO DE-15  /  DAC RESISTIVO ONBOARD',21,INK,True)
text(80,854,'R/G/B: R0=4 kΩ, R1=2 kΩ, R2=1 kΩ, R3=510 Ω; rede e resistor de sincronismo conforme Digilent, folha 2.',15,GRAY)
# R/G/B groups
channels=[('VGA_R','A3 B4 C5 A4','RED','1'),('VGA_G','C6 A5 B6 A6','GREEN','2'),('VGA_B','B7 C7 D7 D8','BLUE','3')]
resvals=['4 kΩ','2 kΩ','1 kΩ','510 Ω']
for ci,(name,pads,color,j2pin) in enumerate(channels):
    x0=85+ci*500; y0=920
    text(x0,y0,name+'[0:3]',17,RED,True)
    node_x=x0+355; top=y0+42; bottom=y0+161
    line(node_x,top,node_x,bottom)
    for bit in range(4):
        yy=top+bit*35
        text(x0,yy+5,f'{name}[{bit}]',14,INK)
        pin=pads.split()[bit]
        text(x0+110,yy+5,pin,14,RED,True)
        line(x0+150,yy,x0+165,yy)
        resistor_h(x0+165,yy,f'R{[111,112,113,115][bit] if ci==0 else [116,117,119,120][bit] if ci==1 else [122,123,125,126][bit]}',resvals[bit],95)
        line(x0+260,yy,node_x,yy); dot(node_x,yy)
    line(node_x,bottom,x0+405,bottom); text(x0+412,bottom+5,'J2 pin '+j2pin+' / '+color,14,BLUE,True)
# syncs lower right
text(80,891,'VGA_HS / B11',13,INK,True); line(195,886,210,886); resistor_h(210,886,'R127','100 Ω',78); line(288,886,310,886); text(320,891,'J2 / 13',13,BLUE,True)
text(870,891,'VGA_VS / B12',13,INK,True); line(985,886,1000,886); resistor_h(1000,886,'R128','100 Ω',78); line(1078,886,1100,886); text(1110,891,'J2 / 14',13,BLUE,True)
text(80,1100,'J2: GND nos contatos 5, 6, 7, 8 e 10 (retorno VGA onboard).',11,GRAY)
sheet2=finish()


# SHEET 3: montagem externa relatada; valores nao fornecidos ficam explicitos.
def ground(x,y):
    line(x,y,x,y+10); line(x-15,y+10,x+15,y+10); line(x-10,y+16,x+10,y+16); line(x-5,y+22,x+5,y+22)
def resistor_v(x,y,label,value):
    line(x,y,x,y+10); rect(x-8,y+10,16,42,'white',BLUE,2); line(x,y+52,x,y+65)
    text(x+18,y+29,label,13,RED,True); text(x+18,y+48,value,12,GRAY)
start();title(3,'Montagem externa na protoboard','Circuitos relatados em bancada. VCC dos módulos: 3,3 V informado; valores de resistores e tensões não medidos.')
chip(55,200,900,560,'KY-023  •  DOIS DIVISORES INDEPENDENTES','Alimentação em JC6; GND em JC5; referências negativas no mesmo GND')
chip(80,300,230,430,'J4  •  KY-023',''); text(98,355,'Pinos pelos nomes',13,GRAY)
text(98,380,'VCC / +5V',15);line(310,375,360,375);text(370,380,'3V3 / JC6',15,BLUE,True)
text(98,420,'GND',15);line(310,415,355,415);ground(355,415)
for name,yy,positive,ref_hi,ref_lo in [('VRx',470,'JXADC1 / A13','RX1','RX2'),('VRy',605,'JXADC2 / A15','RY1','RY2')]:
    text(98,yy+5,name,15);line(310,yy,450,yy);resistor_h(450,yy,ref_hi,'valor NI',100)
    line(550,yy,625,yy);dot(625,yy);line(625,yy,765,yy);text(775,yy+5,positive,15,BLUE,True)
    resistor_v(625,yy,ref_lo,'valor NI');ground(625,yy+65)
line(310,710,800,710);text(98,715,'SW',15);text(810,715,'JC1 / K1',15,BLUE,True)
text(98,750,'JXADC7 / A14 e JXADC8 / A16 → GND comum. Entradas positivas: faixa de conversão 0 a 1 V.',14)
text(80,280,'NI = não informado. Cada eixo mantém seu próprio ponto central; somente GND é compartilhado.',12,GRAY)
chip(990,200,635,560,'Q1  •  BUZZER ATIVO / 2N2222A','Controle em JC7; estágio externo relatado pelo operador')
text(1010,288,'V_BUZ: tensão nominal não informada',15,RED,True)
text(1400,308,'V_BUZ',13,BLUE,True);line(1435,315,1435,345);rect(1403,345,64,55,'white',BLUE,2);text(1435,379,'BZ1',15,INK,True,'middle')
text(1480,355,'+',16,RED,True);text(1480,400,'−',16,BLUE,True);line(1435,400,1435,455)
add('<circle cx="1390" cy="505" r="56" fill="white" stroke="'+BLUE+'" stroke-width="2"/>')
line(1365,472,1365,538);line(1365,488,1435,455);line(1365,522,1435,555);line(1435,555,1435,595)
add('<polygon points="1404,540 1414,527 1425,550" fill="'+BLUE+'"/>');ground(1435,595)
text(1340,493,'B',15,RED,True);text(1450,450,'C',15,RED,True);text(1450,570,'E',15,RED,True)
line(1010,505,1110,505);resistor_h(1110,505,'RB','valor NI',100);line(1210,505,1365,505)
text(1010,480,'JC7 / E7',14,BLUE,True)
text(1010,675,'Emissor → GND; coletor → negativo do buzzer.',15)
text(1010,705,'Diotec TO-92: face plana à frente, E / B / C.',15)
text(1010,735,'Positivo → V_BUZ; tensão e resistor RB ainda pendentes.',14,GRAY)
for x,title_,sda,scl,extra in [(55,'MPU-6050 / GY-521','JD8 / G4','JD7 / H2','AD0 → GND; endereço 0x68'),(590,'BMP085 / SEN-09694','JD1 / H4','JD2 / H1','EOC e XCLR não utilizados'),(1125,'HMC5883L','JD3 / G1','JD9 / G2','DRDY não utilizado')]:
    chip(x,800,500,285,title_,'Barramento I²C independente')
    for yy,name,net in [(895,'SDA',sda),(930,'SCL',scl),(965,'VCC','3V3 relatado'),(1000,'GND','GND comum')]:
        text(x+20,yy,name,15);line(x+88,yy-5,x+215,yy-5);text(x+225,yy,net,15,BLUE,True)
    text(x+20,1040,extra,14)
    text(x+20,1070,'Pull-ups do breakout: presença e valores não medidos.',12,GRAY)
sheet3=finish()

# Save editable vector source as a two-sheet long SVG; PDF is standard two-page A3 landscape.
svg1=OUT/'HUD_FPGA_Esquematico_folha1.svg'; svg2=OUT/'HUD_FPGA_Esquematico_folha2.svg'
svg1.write_text(sheet1,encoding='utf-8'); svg2.write_text(sheet2,encoding='utf-8'); (OUT/'HUD_FPGA_Esquematico_folha3.svg').write_text(sheet3,encoding='utf-8')
# combined SVG concatenates sheets vertically so the full source is editable as one file
body1=re.sub(r'^<svg[^>]*>|</svg>$','',sheet1,flags=re.S)
body2=re.sub(r'^<svg[^>]*>|</svg>$','',sheet2,flags=re.S)
body3=re.sub(r'^<svg[^>]*>|</svg>$','',sheet3,flags=re.S)
combined=f'<svg xmlns="http://www.w3.org/2000/svg" width="420mm" height="891mm" viewBox="0 0 {W} {H*3}"><rect width="100%" height="100%" fill="white"/>{body1}<g transform="translate(0 {H})">{body2}</g><g transform="translate(0 {H*2})">{body3}</g></svg>'
(OUT/'HUD_FPGA_Esquematico.svg').write_text(combined,encoding='utf-8')
# A3 vector pages
pdf_parts=[]
for n,svg in enumerate([sheet1,sheet2,sheet3],1):
    p=OUT/f'.sheet{n}.pdf'; cairosvg.svg2pdf(bytestring=svg.encode(),write_to=str(p),output_width=1587.4,output_height=1122.5); pdf_parts.append(p)
writer=PdfWriter()
for p in pdf_parts:
    for page in PdfReader(str(p)).pages: writer.add_page(page)
with (OUT/'HUD_FPGA_Esquematico.pdf').open('wb') as f: writer.write(f)
for p in pdf_parts: p.unlink()
# high-resolution full two-sheet PNG (2x SVG coordinates)
cairosvg.svg2png(bytestring=combined.encode(),write_to=str(OUT/'HUD_FPGA_Esquematico.png'),output_width=W*2,output_height=H*6)
print(f'Created {len(assign)} physical I/O rows; XDC unique pins verified; output directory: {OUT}')
