# Sensores e entradas externas

Este documento descreve as conexões do top atual, conferidas em `rtl/top_reticula.sv` e `constraints/nexys_a7_reticula.xdc`. A existência de driver e simulação não comprova o funcionamento elétrico da montagem.

| Dispositivo | Conexão atual | Uso no HUD | Limites conhecidos |
| --- | --- | --- | --- |
| MPU-6050 | I²C independente: SDA JD8/G4, SCL JD7/H2 | Accel/gyro para atitude, gyro Z e entradas da estimação vertical | Testes RTL e relato de 13/10: LD4 aceso, ATT BAD ausente e inclinações corretas; precisão não medida |
| BMP085 | I²C independente: SDA JD1/H4, SCL JD2/H1 | Temperatura/pressão compensadas e altitude barométrica | Identificação/cálculos em simulação; LD5 aceso e ALT BAD ausente relatados em 13/10; altitude absoluta não caracterizada |
| HMC5883L | I²C independente: SDA JD3/G1, SCL JD9/G2 | Rumo magnético planar combinado com gyro Z | LD6 aceso e rumo respondendo à rotação relatados em 13/10; sem compensação de inclinação/declinação e precisão não medida |
| KY-023 | Eixos em VAUX3 e VAUX10 via JXADC; botão em JC1/K1 | Movimento da mira em CAÇA e LOCK/UNLOCK | Quatro sentidos, repouso, limites e LOCK/UNLOCK relatados em 13/10; valores dos divisores e faixa analógica não medidos |

## Alimentação e níveis

O XDC especifica `LVCMOS33` para sinais digitais e configura pull-up interno em SDA/SCL do HMC e na entrada do botão do joystick. O BMP e o MPU não têm pull-up indicado no XDC. Verifique a placa breakout, seus reguladores, pull-ups e tensão de sinal antes de conectar. Use terra comum. Não derive a tensão efetiva do módulo apenas do `IOSTANDARD`.

Os dois eixos do KY-023 usam pares diferenciais de canais auxiliares XADC: VAUX3 (JXADC1/7, A13/A14) e VAUX10 (JXADC2/8, A15/A16). A faixa analógica permitida depende da configuração e do dispositivo FPGA; a montagem elétrica precisa respeitá-la. O stub de simulação não valida o ADC físico.

## Seleção e fallback

SW15..SW12=`1111` seleciona a atitude MPU se SW9 estiver desligado; os demais estados selecionam comandos manuais em qualquer modo. SW9 ligado força o modo manual e desativa o processamento da cadeia MPU. SW10 e SW11 desativam o uso do barômetro e magnetômetro; os drivers seguem consultando os sensores. Atitude manual não deve ser interpretada como leitura física. O heading também dispõe de ajuste manual por BTNU/BTND.

VOO e POUSO também simulam grandezas de voo conforme a política operacional; isso não transforma sensores simulados em dados físicos. O heading do HMC é magnético/plano, sem compensação de inclinação ou declinação. A velocidade inercial experimental não é selecionada como velocidade operacional nem mede velocidade no ar.

## Validação pendente

Na bancada, confirmar cada barramento, identificação, leituras em repouso e movimento conhecido, desconexão e recuperação. Registrar orientação dos eixos, faixa observada do joystick, estabilidade do centro e tensão da montagem. LEDs LD4/LD5 informam estados de diagnóstico definidos no RTL, não precisão ou calibração completa.
